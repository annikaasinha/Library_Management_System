package org.example;

import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        System.out.println("Library Portal Initialized….");
        BookManager Library_Books = new BookManager();
        MemberManager Library_Members = new MemberManager();
        System.out.println("---------------------------------");
        while (true) {
            System.out.println("1.    Enter as a librarian");
            System.out.println("2.    Enter as a member");
            System.out.println("3.    Exit");
            Scanner sc = new Scanner(System.in);
            int option = sc.nextInt();
            if (option == 3) {
                System.out.println("---------------------------------");
                System.out.println("Thanks for visiting!");
                System.out.println("---------------------------------");
                break;
            } else if (option == 1) {

                while (true) {
                    System.out.println("---------------------------------");
                    System.out.println("1.    Register a member");
                    System.out.println("2.    Remove a member");
                    System.out.println("3.    Add a book");
                    System.out.println("4.    Remove a book");
                    System.out.println("5.    View all members along with their books and fines to be paid");
                    System.out.println("6.    View all books");
                    System.out.println("7.    Back");
                    Scanner sc2 = new Scanner(System.in);
                    int option2 = sc2.nextInt();
                    if (option2 == 7) {
                        break;

                    } else if (option2 == 1) {
                        Scanner sc3 = new Scanner(System.in);
                        System.out.println("Name: ");
                        String name = sc3.nextLine();
                        System.out.println("Age: ");
                        int age = sc3.nextInt();
                        sc3.nextLine();
                        System.out.println("Phone Number: ");
                        String PhoneNo = sc3.nextLine();
                        Member mem = new Member(name, PhoneNo, age);
                        Library_Members.AddMember(mem);
                        System.out.println("Member successfully generated with the phone number as member id");
                        continue;
                    } else if (option2 == 5) {
                        Library_Members.ViewMembers();
                    } else if (option2 == 2) {
                        Scanner sc3 = new Scanner(System.in);
                        System.out.println("Phone Number: ");
                        String PhoneNo = sc3.nextLine();
                        if (Library_Members.MemberExistence(PhoneNo) == false) {
                            System.out.println("Member not found!");
                        } else {

                            Member mem = Library_Members.SearchMember(PhoneNo);
                            Library_Members.RemoveMember(mem);
                            System.out.println("Member successfully removed");
                        }
                    } else if (option2 == 3) {
                        Scanner sc3 = new Scanner(System.in);
                        System.out.println("Enter the title of the book");
                        String title = sc3.nextLine();
                        System.out.println("Enter the author: ");
                        String author = sc3.nextLine();
                        System.out.println("Enter the number of copies");
                        int noc = sc3.nextInt();
                        Book book = new Book(title, noc, author);
                        Library_Books.AddBook(book);
                        System.out.println("Book added successfully!");
                    } else if (option2 == 6) {
                        Library_Books.ViewBooks();
                    } else if (option2 == 4) {
                        Scanner sc3 = new Scanner(System.in);
                        System.out.println("Enter the book Id");
                        int bookId = sc3.nextInt();
                        if (Library_Books.SearchBookId(bookId) == true) {
                            Book book = Library_Books.Search(bookId);
                            Library_Books.RemoveBook(book);
                            System.out.println("Book removed successfully!");

                        } else {
                            System.out.println("The given book wasn't found!");
                        }

                    }
                }

            } else if (option==2) {
                Scanner sc3 = new Scanner(System.in);
                System.out.println("Name: ");
                String Name = sc3.nextLine();
                System.out.println("Phone Number: ");
                String phone = sc3.nextLine();
                if (Library_Members.MemberExistence(phone) == true) {
                    while (true) {
                        Member mem = Library_Members.SearchMember(phone);
                        Scanner sc4 = new Scanner(System.in);
                        System.out.println("Welcome " + mem.getName());
                        System.out.println("---------------------------------");
                        System.out.println("1.    List of available books");
                        System.out.println("2.    List My Books");
                        System.out.println("3.    Issue book");
                        System.out.println("4.    Return book");
                        System.out.println("5.    Pay Fine");
                        System.out.println("6.    Back");
                        int x = sc4.nextInt();
                        if (x == 1) {
                            Library_Books.ViewBooks();
                        } else if (x == 2) {
                            System.out.println(mem.getBorrowedBooks());
                        } else if (x == 3) {
                            if (mem.getFineamount() > 0) {
                                System.out.println("You need to clear your penalty first");
                            } else {
                                Scanner sc5 = new Scanner(System.in);
                                System.out.println("Enter the book Id: ");
                                int bid = sc5.nextInt();
                                if (Library_Books.SearchBookId(bid) == true) {
                                    Book book = Library_Books.Search(bid);
                                    mem.IssueBook(book);
                                } else {
                                    System.out.println("Book not found!");
                                }

                            }

                        } else if (x == 6) {
                            break;

                        } else if (x==4) {
                            Scanner sc6=new Scanner(System.in);
                            System.out.println("Book Id: ");
                            int bid= sc6.nextInt();
                            if (Library_Books.SearchBookId(bid) == true) {
                                Book book = Library_Books.Search(bid);
                                mem.ReturnBook(book);
                            } else {
                                System.out.println("Book not found!");
                            }

                        } else if (x==5) {
                            Scanner sc7=new Scanner(System.in);
                            System.out.println("Enter the amount you're paying");
                            int amt=sc7.nextInt();
                            mem.setFineamount(mem.getFineamount()-amt);
                            System.out.println("Now the fee amount left is: ");
                            System.out.println(mem.getFineamount());
                        }

                    }
                } else {
                    System.out.println("Member not found. Please recheck your credentials.");
                }

            }

        }
        // Press Shift+F10 or click the green arrow button in the gutter to run the code.

    }
}

