package org.example;

class Book {
    private static int id_initializer=0;
    private int bookId;
    private String title;
    private int no_of_copies;
    private String author;

    public Book(String title, int no_of_copies, String author){
        this.title = title;
        this.no_of_copies = no_of_copies;
        this.bookId= id_initializer++;
        this.author=author;

    }


    public int getBookId() {
        return bookId;
    }

    // Setter method for bookId
    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    // Getter method for title
    public String getTitle() {return title;}
    public String getAuthor(){return author;}
    public void setAuthor(String author){this.author=author;}

    // Setter method for title
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter method for no_of_copies
    public int getNoOfCopies() {
        return no_of_copies;
    }

    // Setter method for no_of_copies
    public void setNoOfCopies(int no_of_copies) {
        this.no_of_copies = no_of_copies;
    }

    @Override
    public String toString() {
        return this.title + "\n" + "Number of copies available: " + this.no_of_copies + "\nBook Id: " + this.bookId;
    }
}