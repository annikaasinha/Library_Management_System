package org.example;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

class Member{
    private String name;
    private String phone_number;
    private int age;
    private Map<Book, LocalDateTime> borrowedBooks;
    private double fineamount=0;
    public String getName(){
        return this.name;
    }

    public double getFineamount() {
        return fineamount;
    }

    public void setFineamount(double fineamount) {
        this.fineamount = fineamount;
    }

    public int getAge() {
        return age;
    }

    public Map<Book, LocalDateTime> getBorrowedBooks() {
        return borrowedBooks;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBorrowedBooks(Map<Book, LocalDateTime> borrowedBooks) {
        this.borrowedBooks = borrowedBooks;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public Member(String name, String phone_number, int age){
        this.phone_number=phone_number;
        this.name=name;
        this.age=age;
        this.borrowedBooks=new HashMap<>();

    }
    @Override
    public String toString() {
        return "Name: " + name + "\n"+" Age: " + age + "\n"+"Phone Number: " + phone_number+"\n"+"Fine amount: "+fineamount+"\n"+"Borrowed Books: "+borrowedBooks;
    }
    public void IssueBook(Book book){
        if (this.borrowedBooks.size()<=2) {
            if (BookManager.SearchBook(book) ==true) {
                LocalDateTime issue_date = LocalDateTime.now();
                this.borrowedBooks.put(book, issue_date);
                book.setNoOfCopies(book.getNoOfCopies() - 1);
                System.out.println("Book Issued Successfully");
            } else {
                System.out.println("Book with the given credentials is not available");
            }
        }
        else{
            System.out.println("you have crossed the limit of issuing 2 books.");
        }
    }
    public void ReturnBook(Book book) {
        if (BookManager.SearchBook(book)) {
            LocalDateTime issue_date = borrowedBooks.get(book);
            System.out.println(issue_date);
            LocalDateTime return_date = LocalDateTime.now();
            System.out.println(return_date);
            book.setNoOfCopies(book.getNoOfCopies()+1);
            borrowedBooks.remove(book);

            long daysBorrowed = issue_date.until(return_date, ChronoUnit.SECONDS);
            System.out.println(daysBorrowed);
            long daysOverdue = daysBorrowed - 10;
            System.out.println(daysOverdue);


            if (daysOverdue > 0) {
                double fineAmount = daysOverdue * 3.0;
                System.out.println("Book returned successfully!");
                System.out.println("Fine Amount: $" + fineAmount);
            } else {
                System.out.println("Book returned successfully!");
            }
        } else {
            System.out.println("Book with the given credentials is not available");
        }
    }
};