package org.example;

import java.util.ArrayList;
import java.util.List;

class MemberManager{
    private static List<Member> MemberList;
    public MemberManager(){
        MemberList= new ArrayList<>();
    }
    public void AddMember(Member member){
        MemberList.add(member);
    }
    public void RemoveMember(Member member){
        MemberList.remove(member);
    }
    public boolean MemberExistence(String Phone){
        for (int i=0; i<MemberList.size(); i++){
            if (MemberList.get(i).getPhone_number().equals(Phone)){
                return true;
            }
        }
        return false;

    }
    public Member SearchMember(String phone){
        for (int i=0; i<MemberList.size(); i++){
            if ((MemberList.get(i).getPhone_number()).equals(phone)){
                return MemberList.get(i);
            }
        }
        return MemberList.get(0);
    }


    public void ViewMembers() {
        for (int i = 0; i < MemberList.size(); i++) {
            Member x= MemberList.get(i);
            System.out.println(x);
        }
    }


}
