package org.example;

import java.util.ArrayList;
import java.util.List;

class BookManager {
    public static List<Book> BookList;

    public BookManager() {
        BookList = new ArrayList<>();
    }

    public static void AddBook(Book book) {
        BookList.add(book);
    }

    public static void RemoveBook(Book book) {
        BookList.remove(book);
    }

    public void ViewBooks() {
        for (int i = 0; i < BookList.size(); i++) {
            if (BookList.get(i).getNoOfCopies() > 0) {
                System.out.println(BookList.get(i));
            }
            // Other methods for book management
        }
    }
    public static boolean SearchBookId(int bookId){
        for(int j=0; j< BookList.size();j++) {
            if ((BookList.get(j).getBookId())==bookId){
                return true;
            }
        }
        return false;

    }
    //confirm whether it will be static method or instance method
    public static boolean SearchBook(Book book){
        for(int j=0; j< BookList.size();j++) {
            if ((BookList.get(j).getBookId())==(book.getBookId())){
                return true;
            }

        }
        return false;
    }
    public static Book Search(int bookId){
        for(int j=0; j< BookList.size();j++) {
            if ((BookList.get(j).getBookId())==bookId){
                return BookList.get(j);
            }
        }
        return BookList.get(0);

    }
}
